The functions that were written before in the code are unchanged and work how you implmented them. The input is still the same, but
I haven't tried to use negative numbers, and I went with the connected components function for part 4.
My queue and stack implmentations were not the best and used strings to store the data.
It would've been much better to use literally anything else because of all of the converting that needed to be done, but everything
should be functional.